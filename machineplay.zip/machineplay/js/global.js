/**
 * @file
 * Global utilities.
 *
 */
(function($, Drupal) {

    'use strict';

    Drupal.behaviors.machineplay = {
        attach: function(context, settings) {

        }
    };

})(jQuery, Drupal);

// Header Search Toggle
jQuery('.header_wrapper .block-search .search__icon').click(function() {
    jQuery('.header_wrapper .block-search .search_wrapper').toggle('slow');
});

// Slider

jQuery('.view-banner .view-content.row').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: false,
    fade: false,
    asNavFor: '.nav__slider'
});
jQuery('.nav__slider').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    asNavFor: '.view-banner .view-content.row',
    dots: false,
    centerMode: false,
    focusOnSelect: true
});

// Header Menu Toggle

jQuery('.main_menu .navbar-toggler').click(function() {
    jQuery('.main_menu .region-secondary-menu').toggle('slow');
})